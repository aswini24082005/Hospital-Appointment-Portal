from django.urls import path
from . import views

urlpatterns = [
    # Home and Auth
    path('', views.home, name='home'),
    path('logout/', views.logout_view, name='logout'),
    
    # Doctor Registration and Login
    path('doctor/register/', views.doctor_register, name='doctor_register'),
    path('doctor/login/', views.doctor_login, name='doctor_login'),
    
    # Patient Registration and Login
    path('patient/register/', views.patient_register, name='patient_register'),
    path('patient/login/', views.patient_login, name='patient_login'),
    
    # Doctor Routes
    path('doctor/dashboard/', views.doctor_dashboard, name='doctor_dashboard'),
    path('doctor/add-slot/', views.add_time_slot, name='add_time_slot'),
    path('doctor/manage-slots/', views.manage_slots, name='manage_slots'),
    path('doctor/delete-slot/<int:slot_id>/', views.delete_slot, name='delete_slot'),
    
    # Patient Routes
    path('patient/dashboard/', views.patient_dashboard, name='patient_dashboard'),
    path('patient/book-appointment/', views.book_appointment, name='book_appointment'),
    path('patient/book-appointment/<int:doctor_id>/', views.book_appointment, name='book_appointment_doctor'),
    path('patient/appointment/<int:appointment_id>/', views.appointment_detail, name='appointment_detail'),
    path('patient/reschedule/<int:appointment_id>/', views.reschedule_appointment, name='reschedule_appointment'),
    path('patient/cancel/<int:appointment_id>/', views.cancel_appointment, name='cancel_appointment'),
    
    # Directory
    path('doctors/', views.doctor_directory, name='doctor_directory'),
    path('doctor/<int:doctor_id>/', views.doctor_profile, name='doctor_profile'),
]