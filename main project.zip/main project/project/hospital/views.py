from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.utils import timezone
from django.http import JsonResponse, HttpResponseForbidden
from django.views.decorators.http import require_http_methods
from datetime import timedelta

from .models import (
    User, UserRole, Doctor, Patient, TimeSlot, Appointment
)
from .forms import (
    DoctorRegisterForm, PatientRegisterForm, TimeSlotForm,
    AppointmentForm, RescheduleAppointmentForm, SlotSelectionForm
)


# ======================= Authentication Views =======================

def home(request):
    """Home page with role selection"""
    if request.user.is_authenticated:
        try:
            if request.user.role.role == 'doctor':
                return redirect('doctor_dashboard')
            else:
                return redirect('patient_dashboard')
        except:
            pass
    return render(request, 'hospital/home.html')


def doctor_register(request):
    """Doctor registration"""
    if request.method == 'POST':
        form = DoctorRegisterForm(request.POST)
        if form.is_valid():
            user = form.save()
            Doctor.objects.create(
                user=user,
                specialization=form.cleaned_data['specialization'],
                license_number=form.cleaned_data['license_number'],
                phone=form.cleaned_data['phone'],
                bio=form.cleaned_data.get('bio', '')
            )
            UserRole.objects.create(user=user, role='doctor')
            messages.success(request, 'Doctor account created successfully! Please login.')
            return redirect('doctor_login')
    else:
        form = DoctorRegisterForm()
    return render(request, 'hospital/doctor_register.html', {'form': form})


def patient_register(request):
    """Patient registration"""
    if request.method == 'POST':
        form = PatientRegisterForm(request.POST)
        if form.is_valid():
            user = form.save()
            Patient.objects.create(
                user=user,
                date_of_birth=form.cleaned_data.get('date_of_birth'),
                phone=form.cleaned_data['phone'],
                address=form.cleaned_data.get('address', ''),
                medical_history=form.cleaned_data.get('medical_history', '')
            )
            UserRole.objects.create(user=user, role='patient')
            messages.success(request, 'Patient account created successfully! Please login.')
            return redirect('patient_login')
    else:
        form = PatientRegisterForm()
    return render(request, 'hospital/patient_register.html', {'form': form})


def doctor_login(request):
    """Doctor login"""
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        user = authenticate(request, username=username, password=password)
        if user is not None:
            try:
                if user.role.role == 'doctor':
                    login(request, user)
                    return redirect('doctor_dashboard')
                else:
                    messages.error(request, 'This account is not a doctor account.')
            except:
                messages.error(request, 'Invalid credentials.')
        else:
            messages.error(request, 'Invalid username or password.')
    return render(request, 'hospital/doctor_login.html')


def patient_login(request):
    """Patient login"""
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        user = authenticate(request, username=username, password=password)
        if user is not None:
            try:
                if user.role.role == 'patient':
                    login(request, user)
                    return redirect('patient_dashboard')
                else:
                    messages.error(request, 'This account is not a patient account.')
            except:
                messages.error(request, 'Invalid credentials.')
        else:
            messages.error(request, 'Invalid username or password.')
    return render(request, 'hospital/patient_login.html')


def logout_view(request):
    """Logout user"""
    logout(request)
    messages.success(request, 'Logged out successfully.')
    return redirect('home')


# ======================= Doctor Views =======================

@login_required(login_url='doctor_login')
def doctor_dashboard(request):
    """Doctor dashboard with appointments and slot management"""
    try:
        doctor = request.user.doctor_profile
        if request.user.role.role != 'doctor':
            return HttpResponseForbidden("You don't have access to this page.")
    except:
        return HttpResponseForbidden("You don't have access to this page.")

    # Get all appointments for this doctor
    today = timezone.now()
    upcoming_appointments = Appointment.objects.filter(
        doctor=doctor,
        appointment_date__gte=today,
        status__in=['scheduled', 'rescheduled']
    ).order_by('appointment_date')

    completed_appointments = Appointment.objects.filter(
        doctor=doctor,
        status='completed'
    ).order_by('-appointment_date')[:5]

    # Get available and booked slots
    available_slots = TimeSlot.objects.filter(
        doctor=doctor,
        status='available',
        start_time__gt=today
    ).order_by('start_time')[:10]

    booked_slots = TimeSlot.objects.filter(
        doctor=doctor,
        status='booked',
        start_time__gt=today
    ).order_by('start_time')[:10]

    context = {
        'doctor': doctor,
        'upcoming_appointments': upcoming_appointments,
        'completed_appointments': completed_appointments,
        'available_slots': available_slots,
        'booked_slots': booked_slots,
    }
    return render(request, 'hospital/doctor_dashboard.html', context)


@login_required(login_url='doctor_login')
def add_time_slot(request):
    """Add available time slots"""
    try:
        doctor = request.user.doctor_profile
        if request.user.role.role != 'doctor':
            return HttpResponseForbidden("You don't have access to this page.")
    except:
        return HttpResponseForbidden("You don't have access to this page.")

    if request.method == 'POST':
        form = TimeSlotForm(request.POST)
        if form.is_valid():
            slot = form.save(commit=False)
            slot.doctor = doctor
            slot.full_clean()
            slot.save()
            messages.success(request, 'Time slot added successfully!')
            return redirect('doctor_dashboard')
    else:
        form = TimeSlotForm()

    return render(request, 'hospital/add_time_slot.html', {'form': form})


@login_required(login_url='doctor_login')
def manage_slots(request):
    """Manage all time slots"""
    try:
        doctor = request.user.doctor_profile
        if request.user.role.role != 'doctor':
            return HttpResponseForbidden("You don't have access to this page.")
    except:
        return HttpResponseForbidden("You don't have access to this page.")

    today = timezone.now()
    upcoming_slots = TimeSlot.objects.filter(
        doctor=doctor,
        start_time__gte=today
    ).order_by('start_time')

    past_slots = TimeSlot.objects.filter(
        doctor=doctor,
        start_time__lt=today
    ).order_by('-start_time')

    context = {
        'upcoming_slots': upcoming_slots,
        'past_slots': past_slots,
    }
    return render(request, 'hospital/manage_slots.html', context)


@login_required(login_url='doctor_login')
def delete_slot(request, slot_id):
    """Delete a time slot"""
    try:
        doctor = request.user.doctor_profile
        if request.user.role.role != 'doctor':
            return HttpResponseForbidden("You don't have access to this page.")
    except:
        return HttpResponseForbidden("You don't have access to this page.")

    slot = get_object_or_404(TimeSlot, id=slot_id, doctor=doctor)
    
    if slot.status == 'booked':
        # Cancel appointment if slot is booked
        try:
            appointment = Appointment.objects.get(time_slot=slot)
            appointment.status = 'cancelled'
            appointment.save()
        except:
            pass

    slot.delete()
    messages.success(request, 'Time slot deleted successfully!')
    return redirect('manage_slots')


# ======================= Patient Views =======================

@login_required(login_url='patient_login')
def patient_dashboard(request):
    """Patient dashboard with appointments"""
    try:
        patient = request.user.patient_profile
        if request.user.role.role != 'patient':
            return HttpResponseForbidden("You don't have access to this page.")
    except:
        return HttpResponseForbidden("You don't have access to this page.")

    today = timezone.now()
    upcoming_appointments = Appointment.objects.filter(
        patient=patient,
        appointment_date__gte=today,
        status__in=['scheduled', 'rescheduled']
    ).order_by('appointment_date')

    past_appointments = Appointment.objects.filter(
        patient=patient,
        appointment_date__lt=today,
        status__in=['completed', 'cancelled']
    ).order_by('-appointment_date')[:5]

    context = {
        'patient': patient,
        'upcoming_appointments': upcoming_appointments,
        'past_appointments': past_appointments,
    }
    return render(request, 'hospital/patient_dashboard.html', context)


@login_required(login_url='patient_login')
def book_appointment(request, doctor_id=None):
    """Book an appointment"""
    try:
        patient = request.user.patient_profile
        if request.user.role.role != 'patient':
            return HttpResponseForbidden("You don't have access to this page.")
    except:
        return HttpResponseForbidden("You don't have access to this page.")

    if request.method == 'POST':
        doctor_id = request.POST.get('doctor')
        slot_id = request.POST.get('time_slot')
        reason = request.POST.get('reason')

        try:
            doctor = Doctor.objects.get(id=doctor_id)
            time_slot = TimeSlot.objects.get(id=slot_id, status='available')

            # Create appointment
            appointment = Appointment.objects.create(
                patient=patient,
                doctor=doctor,
                time_slot=time_slot,
                appointment_date=time_slot.start_time,
                reason=reason,
                status='scheduled'
            )

            # Mark slot as booked
            time_slot.status = 'booked'
            time_slot.save()

            messages.success(request, 'Appointment booked successfully!')
            return redirect('patient_dashboard')
        except TimeSlot.DoesNotExist:
            messages.error(request, 'Selected time slot is no longer available.')
        except Doctor.DoesNotExist:
            messages.error(request, 'Doctor not found.')
        except Exception as e:
            messages.error(request, f'An error occurred: {str(e)}')
    else:
        # GET request - show booking form
        if doctor_id:
            doctor = get_object_or_404(Doctor, id=doctor_id)
            today = timezone.now()
            available_slots = TimeSlot.objects.filter(
                doctor=doctor,
                status='available',
                start_time__gt=today
            ).order_by('start_time')
            return render(request, 'hospital/book_appointment.html', {
                'doctor': doctor,
                'available_slots': available_slots,
            })
        else:
            doctors = Doctor.objects.all()
            return render(request, 'hospital/select_doctor.html', {'doctors': doctors})


@login_required(login_url='patient_login')
def appointment_detail(request, appointment_id):
    """View appointment details"""
    try:
        patient = request.user.patient_profile
        if request.user.role.role != 'patient':
            return HttpResponseForbidden("You don't have access to this page.")
    except:
        return HttpResponseForbidden("You don't have access to this page.")

    appointment = get_object_or_404(Appointment, id=appointment_id, patient=patient)
    return render(request, 'hospital/appointment_detail.html', {'appointment': appointment})


@login_required(login_url='patient_login')
def reschedule_appointment(request, appointment_id):
    """Reschedule an appointment"""
    try:
        patient = request.user.patient_profile
        if request.user.role.role != 'patient':
            return HttpResponseForbidden("You don't have access to this page.")
    except:
        return HttpResponseForbidden("You don't have access to this page.")

    appointment = get_object_or_404(Appointment, id=appointment_id, patient=patient)

    if not appointment.can_reschedule():
        messages.error(request, 'This appointment cannot be rescheduled.')
        return redirect('appointment_detail', appointment_id=appointment.id)

    if request.method == 'POST':
        form = RescheduleAppointmentForm(appointment.doctor, request.POST)
        if form.is_valid():
            new_slot = form.cleaned_data['time_slot']

            # Release old slot
            if appointment.time_slot:
                appointment.time_slot.status = 'available'
                appointment.time_slot.save()

            # Update appointment
            appointment.time_slot = new_slot
            appointment.appointment_date = new_slot.start_time
            appointment.status = 'rescheduled'
            appointment.save()

            # Mark new slot as booked
            new_slot.status = 'booked'
            new_slot.save()

            messages.success(request, 'Appointment rescheduled successfully!')
            return redirect('patient_dashboard')
    else:
        form = RescheduleAppointmentForm(appointment.doctor)

    context = {
        'appointment': appointment,
        'form': form,
    }
    return render(request, 'hospital/reschedule_appointment.html', context)


@login_required(login_url='patient_login')
def cancel_appointment(request, appointment_id):
    """Cancel an appointment"""
    try:
        patient = request.user.patient_profile
        if request.user.role.role != 'patient':
            return HttpResponseForbidden("You don't have access to this page.")
    except:
        return HttpResponseForbidden("You don't have access to this page.")

    appointment = get_object_or_404(Appointment, id=appointment_id, patient=patient)

    if not appointment.can_cancel():
        messages.error(request, 'This appointment cannot be cancelled.')
        return redirect('appointment_detail', appointment_id=appointment.id)

    if request.method == 'POST':
        # Release the slot
        if appointment.time_slot:
            appointment.time_slot.status = 'available'
            appointment.time_slot.save()

        # Cancel appointment
        appointment.status = 'cancelled'
        appointment.save()

        messages.success(request, 'Appointment cancelled successfully!')
        return redirect('patient_dashboard')

    return render(request, 'hospital/cancel_appointment.html', {'appointment': appointment})


# ======================= Doctor Directory =======================

def doctor_directory(request):
    """Browse all doctors"""
    doctors = Doctor.objects.all()
    specialization = request.GET.get('specialization', '')

    if specialization:
        doctors = doctors.filter(specialization=specialization)

    context = {
        'doctors': doctors,
        'specializations': Doctor.SPECIALIZATION_CHOICES,
        'selected_specialization': specialization,
    }
    return render(request, 'hospital/doctor_directory.html', context)


def doctor_profile(request, doctor_id):
    """View doctor profile and available slots"""
    doctor = get_object_or_404(Doctor, id=doctor_id)
    today = timezone.now()
    available_slots = TimeSlot.objects.filter(
        doctor=doctor,
        status='available',
        start_time__gt=today
    ).order_by('start_time')[:10]

    context = {
        'doctor': doctor,
        'available_slots': available_slots,
    }
    return render(request, 'hospital/doctor_profile.html', context)

