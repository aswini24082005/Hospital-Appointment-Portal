from django import forms
from django.contrib.auth.models import User
from django.contrib.auth.forms import UserCreationForm
from .models import Doctor, Patient, TimeSlot, Appointment
from django.utils import timezone


class UserRegisterForm(UserCreationForm):
    email = forms.EmailField(required=True)
    first_name = forms.CharField(max_length=30, required=True)
    last_name = forms.CharField(max_length=30, required=True)

    class Meta:
        model = User
        fields = ['username', 'email', 'first_name', 'last_name', 'password1', 'password2']


class DoctorRegisterForm(UserRegisterForm):
    specialization = forms.ChoiceField(choices=Doctor.SPECIALIZATION_CHOICES)
    license_number = forms.CharField(max_length=50)
    phone = forms.CharField(max_length=15)
    bio = forms.CharField(widget=forms.Textarea, required=False)

    class Meta:
        model = User
        fields = ['username', 'email', 'first_name', 'last_name', 'password1', 'password2']


class PatientRegisterForm(UserRegisterForm):
    date_of_birth = forms.DateField(required=False, widget=forms.DateInput(attrs={'type': 'date'}))
    phone = forms.CharField(max_length=15)
    address = forms.CharField(widget=forms.Textarea, required=False)
    medical_history = forms.CharField(widget=forms.Textarea, required=False)

    class Meta:
        model = User
        fields = ['username', 'email', 'first_name', 'last_name', 'password1', 'password2']


class TimeSlotForm(forms.ModelForm):
    class Meta:
        model = TimeSlot
        fields = ['start_time', 'end_time']
        widgets = {
            'start_time': forms.DateTimeInput(attrs={'type': 'datetime-local', 'class': 'form-control'}),
            'end_time': forms.DateTimeInput(attrs={'type': 'datetime-local', 'class': 'form-control'}),
        }

    def clean(self):
        cleaned_data = super().clean()
        start_time = cleaned_data.get('start_time')
        end_time = cleaned_data.get('end_time')

        if start_time and end_time:
            if start_time >= end_time:
                raise forms.ValidationError("Start time must be before end time")
            if start_time <= timezone.now():
                raise forms.ValidationError("Slot time must be in the future")


class AppointmentForm(forms.ModelForm):
    class Meta:
        model = Appointment
        fields = ['doctor', 'reason']
        widgets = {
            'doctor': forms.Select(attrs={'class': 'form-control'}),
            'reason': forms.Textarea(attrs={'class': 'form-control', 'rows': 4}),
        }


class RescheduleAppointmentForm(forms.Form):
    time_slot = forms.ModelChoiceField(
        queryset=TimeSlot.objects.filter(status='available'),
        widget=forms.Select(attrs={'class': 'form-control'})
    )

    def __init__(self, doctor=None, *args, **kwargs):
        super().__init__(*args, **kwargs)
        if doctor:
            self.fields['time_slot'].queryset = TimeSlot.objects.filter(
                doctor=doctor,
                status='available',
                start_time__gt=timezone.now()
            ).order_by('start_time')


class SlotSelectionForm(forms.Form):
    time_slot = forms.ModelChoiceField(
        queryset=TimeSlot.objects.filter(status='available'),
        widget=forms.Select(attrs={'class': 'form-control'})
    )

    def __init__(self, doctor=None, *args, **kwargs):
        super().__init__(*args, **kwargs)
        if doctor:
            self.fields['time_slot'].queryset = TimeSlot.objects.filter(
                doctor=doctor,
                status='available',
                start_time__gt=timezone.now()
            ).order_by('start_time')
