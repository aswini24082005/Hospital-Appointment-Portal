from django.contrib import admin
from .models import UserRole, Doctor, Patient, TimeSlot, Appointment


@admin.register(UserRole)
class UserRoleAdmin(admin.ModelAdmin):
    list_display = ('user', 'role')
    list_filter = ('role',)
    search_fields = ('user__username',)


@admin.register(Doctor)
class DoctorAdmin(admin.ModelAdmin):
    list_display = ('get_name', 'specialization', 'license_number', 'phone', 'created_at')
    list_filter = ('specialization', 'created_at')
    search_fields = ('user__first_name', 'user__last_name', 'license_number')
    readonly_fields = ('created_at',)

    def get_name(self, obj):
        return f"Dr. {obj.user.first_name} {obj.user.last_name}"
    get_name.short_description = 'Doctor'


@admin.register(Patient)
class PatientAdmin(admin.ModelAdmin):
    list_display = ('get_name', 'phone', 'date_of_birth', 'created_at')
    list_filter = ('created_at',)
    search_fields = ('user__first_name', 'user__last_name', 'phone')
    readonly_fields = ('created_at',)

    def get_name(self, obj):
        return f"{obj.user.first_name} {obj.user.last_name}"
    get_name.short_description = 'Patient'


@admin.register(TimeSlot)
class TimeSlotAdmin(admin.ModelAdmin):
    list_display = ('doctor', 'start_time', 'end_time', 'status')
    list_filter = ('status', 'start_time', 'doctor')
    search_fields = ('doctor__user__first_name', 'doctor__user__last_name')
    readonly_fields = ('created_at',)


@admin.register(Appointment)
class AppointmentAdmin(admin.ModelAdmin):
    list_display = ('id', 'patient', 'doctor', 'appointment_date', 'status', 'created_at')
    list_filter = ('status', 'appointment_date', 'created_at')
    search_fields = ('patient__user__first_name', 'doctor__user__first_name', 'reason')
    readonly_fields = ('created_at', 'updated_at')
